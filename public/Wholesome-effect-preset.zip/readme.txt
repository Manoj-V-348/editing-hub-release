--WHOLESOME EFFECT--

HOW TO USE :

1. Create a "Color Matte" in your adobe premiere pro project and set the color to PINK.
2. Drag and drop the "Wholesome effect" preset to your Pink color matte.
3. Adjust the "Mask path and feather" to match your interest.
