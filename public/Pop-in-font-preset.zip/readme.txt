--POP-IN FONT PRESET--

HOW TO USE :

1. Create a new text file in your project.
2. Before adding text into the text file, drag and drop the "Pop-in font preset" to the text file.
3. Change the font according to your interest.
4. *SCROLL TO THE BOTTOM AND CHANGE THE POSITION ONLY IN THE -VIDEO- AREA. DO NOT CHANGE VALUES OF TRANSFORM OR VECTOR MOTION EFFECT*