--BLACK VIGNETTE EFFECT--

HOW TO USE :

1. Create a Black Video or Black color matte in your Adobe premiere pro project.
2. Place the Black video / color matte above your desired clip.
3. Drag and drop the "Black Vignette effect" preset to the Black Video / Color matte.
4. Adjust the "Mask path, feather, expansion" to your interest.