--COMIC FONT PRESET--

HOW TO USE :

1. Create a color matte inside your Adobe premiere pro project.
2. Drag and drop the "Comic strip dotted" preset into the Color matte.
3. Increase or decrease the size from the cell pattern effect to match your interest.
4. Change the color to your choice.
5. Add the text and change the font to "Comic Sans font".
6. Drag and drop the "Sharp comic style shadow" preset to both layers and change color of your choice.
7. Nest both the Layers.