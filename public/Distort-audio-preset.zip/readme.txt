--DISTORT AUDIO PRESET--

HOW TO USE : 

1. Drag and drop the "Distort audio" preset to your audio file.
2. Adjust the volume so that the volume is neither too low nor too high.