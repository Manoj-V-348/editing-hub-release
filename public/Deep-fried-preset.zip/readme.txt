--DEEP FRIED PRESET--

HOW TO USE :

1. Drag and drop the "Deep Fried" preset to your Clip.
2. Adjust the effects to match your Clip.
3. TIP : Use effect on an Adjustment layer to have additional advantages.