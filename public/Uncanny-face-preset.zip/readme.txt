--UNCANNY FACE EFFECT--

HOW TO USE :

1. Drag and drop the "Uncanny face" preset to your desired clip.
2. Adjust the Lumetri color values to your interest.
3. TIP : Add to adjustment layer for additional perks.